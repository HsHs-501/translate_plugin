# Agent Instructions

Instructions for agents working in this repository. Read this before you touch anything.

## Project

This repository holds Hozy's plugins for Valenced, a Discord Android client mod. It was created from the plugin template (`revenge-plugin-template` layout).

Rules:

1. Every plugin name starts with `Hozy` (example: `Hozy's Translator`). Plugin ids use `dev.hozy.<name>`.
2. All user-facing text in plugins is English.
3. The target is Valenced. It uses `@valenced/*` imports and `valenced.api` in manifests. Revenge Next uses `@revenge-mod/*` and `revenge.api`. Keep every host import in `js/compat.ts` so one file swaps the namespace.
4. Do not write Classic plugins (`vendetta` global, `manifest.json` plus loose `index.js`).

Layout:

- `plugins/<name>/manifest.json` holds plugin metadata: `format`, `id`, `name`, `author`, `description`, `version`, `dependencies`, `dist`.
- `plugins/<name>/js/index.tsx` is the entry point.
- `plugins/<name>/tsconfig.json` extends `../../tsconfig.base.json`.
- Do not add Kotlin (`src/main`). Its build needs GitHub Packages credentials and fails with a 401.
- `.github/workflows/`: `validate.yml`, `release.yml`, `publish-index.yml`. CI publishes to the `gh-pages` branch.

A release needs a new `version` in the manifest. Without a bump, CI publishes nothing.

## Deno

Check the CLI first:

```
deno --version
```

If it prints 2.9 or later, continue. If it is older, run `deno upgrade`. If the command is missing, ask the user before you install it. Show these commands:

```
# Windows (PowerShell)
irm https://deno.land/install.ps1 | iex
# macOS / Linux
curl -fsSL https://deno.land/install.sh | sh
```

Deno reads `package.json`. Do not move the project to JSR, drop `package.json`, or rewrite imports.

```
deno install
deno task build
deno task lint
deno task lint:types
```

1. Do not pass `-A`. Add the one permission a failure names.
2. If a build fails on npm lifecycle scripts, run `deno install --allow-scripts=npm:@swc/core,npm:@revenge-mod/plugin-cli`.
3. Some dependencies use `git+https://` specifiers. Deno support is unverified. If `deno install` rejects them, tell the user and fall back to `bun install` or `npm install`.
4. Do not install agent skills unless the user asks.

## Plugin API facts

Verified from the Valenced "Your First Plugin" page:

- `plugin<{ jsonStorage: Settings }>({ jsonStorage: { load: true, default }, start({ cleanup, jsonStorage, logger }) {...}, SettingsComponent({ api }) {...} })`.
- Lifecycles: `preInit`, `init`, `start`, `stop`. Most plugins use `start` only.
- `cleanup(...)` registers teardown. Call `plugin.requireReload()` when a change cannot be undone at runtime.
- `api.jsonStorage.use()` reads settings in UI. `api.jsonStorage.set({...})` writes. `jsonStorage.cache` reads in `start`.
- `Design.TableRowGroup` and `Design.TableSwitchRow` exist. Other Design components are unverified. Check `@valenced/discord/design` before use.
- `onFluxEventDispatched` from `@valenced/discord/flux` intercepts Flux events. Return the payload to pass it on, or return nothing to drop it.
- Use `getModules` or `waitForModules` for lookups. Avoid eager lookups at startup.
- Do not read installation directories at runtime. Use `jsonStorage`.

Unverified for Valenced (mirrored from Revenge): `@valenced/modules/finders`, `@valenced/modules/finders/filters`, `@valenced/patcher`, `@valenced/discord/actions`.

From the Revenge Next repository (likely shared by Valenced):

- A filter can receive `undefined`, `null`, a primitive, a function, or a proxy. Guard your inputs.
- A failed Metro factory poisons its module for the session. Never throw at module scope in early code.
- Patch module exports, not a fiber `type`.
- Look in the Design barrel before you hunt module IDs.

## Installing in the app

1. Settings > Valenced > Plugins.
2. Tap the gear icon (top right). The Advanced page opens.
3. Paste the repository URL in `Repository URL`. Tap `Add repository`.
4. Go back to Plugins. Tap `+`.
5. `Install from file` on the Advanced page installs a plugin ZIP directly.

The repository URL is `https://hshs-501.github.io/Translate-Plugin/`.

Unofficial repositories can break the install. Do not report issues for them in `#help-support-here`.

## Pitfalls seen on this user's device

- Discord 350.8 on Android. A toast call crashed the app with `Cannot read property 'position' of undefined` in `ToastContainer`. Do not use the Toast API.
- Show a message only the user can see with `sendBotMessage` from a module finder. Fall back to an alert modal.
- The message long-press sheet has no documented extension point. Treat patches of it as unverified and say so.

## Workflow

1. `deno install`
2. `deno task build`
3. `deno task lint` and `deno task lint:types`
4. Bump `version` in the manifest.
5. Commit and push. Check that Actions turns green.
6. Check that `index.json` on GitHub Pages lists the plugin.

## Rules

- Follow the existing style of the file you edit. Do not refactor unasked.
- Do not invent API names. Check the docs, or say you are unsure.
- Finish every task with a list of internals you did not verify.
- Do not add features the user did not ask for. Propose them first.
- Do not create documentation files unless the user asks.
