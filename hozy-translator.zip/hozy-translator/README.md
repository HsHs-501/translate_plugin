# Hozy's Translator

بلقن ترجمة لـ **Valenced**: اضغط طويل على أي رسالة ثم **Translate**، والترجمة تجيك كرسالة محلية ما يشوفها غيرك.
الخدمات: **Google Translate** و**Microsoft Translate** و**Brave Translate** (تختارها من إعدادات البلقن).

## الملفات
كلها داخل `plugins/hozy-translator/`:

    manifest.json        بيانات البلقن (id: dev.hozy.translator)
    tsconfig.json
    js/index.tsx         الزر + إرسال الترجمة
    js/providers.ts      Google و Microsoft و Brave
    js/languages.ts      قائمة اللغات
    js/settings.tsx      الإعدادات (الخدمة، من لغة، إلى لغة)
    js/compat.ts         كل استيرادات الـ API من التطبيق (مكان واحد)

---

## الجزء 1: انشر البلقن في مستودعك

1. انسخ مجلد `hozy-translator` إلى مجلد `plugins/` في مشروع الـ template (مشروع `Translate-Plugin`).
2. (اختياري) احذف مجلد `plugins/translate` القديم لو ما تبي نسخة Translate القديمة تنشر معه.
3. ارفع التغييرات إلى GitHub (Commit ثم Push).
4. افتح تبويب **Actions** وانتظر علامة ✅. لو طلعت ❌ انسخ لي الخطأ.
5. تأكد إن **Settings > Pages** مفعّل على فرع `gh-pages` و`/ (root)`.
6. رابط مستودعك للتطبيق:

       https://hshs-501.github.io/Translate-Plugin/

   افتحه في المتصفح مع `index.json` في آخره، ولازم يطلع لك نص فيه `dev.hozy.translator`.

كل ما عدلت الكود، غيّر `"version"` في `plugins/hozy-translator/manifest.json` (مثلا `1.0.1`)، وإلا CI ما ينشر نسخة جديدة.

---

## الجزء 2: ثبّته في Valenced (نفس خطوات منشور unofficial-repos)

> **تنبيه من سيرفر Valenced الرسمي:** المستودعات غير الرسمية ممكن تخرب تثبيتك أو تكون غير آمنة، وما يراجعونها غالبا. لا تبلّغ عن مشاكل بلقنات غير رسمية في قناة `#help-support-here`.

1. افتح **Settings** ثم **Valenced** ثم **Plugins**.
2. اضغط أيقونة الترس ⚙️ فوق يمين، تفتح صفحة **Advanced**.
3. في خانة **Repository URL** الصق رابط مستودعك:

       https://hshs-501.github.io/Translate-Plugin/

   ثم اضغط **Add repository**.
4. ارجع لصفحة **Plugins** واضغط **+**.
5. المفروض يظهر **Hozy's Translator**. لو ما ظهر، افتح صفحة **Advanced** واضغط **Check for updates**.
6. تقدر تفلتر البلقنات حسب المستودع بالضغط على أيقونة الفلتر جنب شريط البحث.
7. ثبّته وفعّله، وافتح إعداداته واختر **Translation service** و**Translate from** و**Translate to**.
8. اضغط طويل على أي رسالة ثم **Translate**.

### طريقة ثانية: Install from file (بدون إضافة مستودع)
صفحة **Advanced** فيها خيار **Install from file**:
1. نزّل ملف البلقن من مستودعك على الجوال (الاسم يكون على شكل `id@version`):

       https://hshs-501.github.io/Translate-Plugin/pool/dev.hozy.translator@1.0.0.zip

2. في **Advanced** اضغط **Install from file** واختر الملف.

### التحديثات
في **Advanced** فيه **Update plugins automatically**، ويفحص المستودعات بعد تشغيل التطبيق. وزر **Check for updates** يفحص يدويا.

---

## لو تستعمل Revenge Next بدل Valenced
غيّر شيئين:
1. في `js/compat.ts`: بدّل `@valenced/` إلى `@revenge-mod/` في كل الأسطر.
2. في `manifest.json`: بدّل `"valenced.api"` إلى `"revenge.api"`.

## ملاحظات مهمة
- **Brave Translate:** ما له API رسمي موثق. البلقن يستعمل سيرفر Brave بصيغة Chromium، وممكن يرفض الطلبات أو يتغير بدون إنذار. لو فشل جرب Google أو Microsoft.
- **Microsoft Translate:** يستعمل خدمة Edge المجانية (بدون مفتاح). غير رسمية وممكن تتوقف.
- بعض اللغات ممكن ما تدعمها خدمة معينة، فيطلع لك خطأ بدل الترجمة.
- أسماء أجزاء Discord الداخلية (زر الضغط الطويل، الرسائل المحلية) ما جربتها على جهاز. لو ما ظهر الزر، افتح Debug Logs وابحث عن `Could not find the button list`.
